@extends('layout/main')
@section('title','Web Programming Unpas')
@section('container')
<div class="container">
    <div class="row">
        <div class="col-10">
            <h1 class="mt-3">Hello, world!</h1>
        </div>
    </div>
</div>
@endsection